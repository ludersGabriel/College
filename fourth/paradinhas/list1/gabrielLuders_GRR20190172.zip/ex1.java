class ex1 {
  public static void main( String args[] ){
    System.out.printf("Tabuada do 6\n");
    
    for(int i = 0; i <= 10; i++){
      System.out.printf("6 * %d = %d\n", i, i*6);
    }
  }
}