class ex3 {
  public static void main( String args[] ){
    System.out.printf("Nome: Gabriel Lüders\n");
    System.out.printf("Time favorito: Flamengo\n");
    System.out.printf("Bairro: Alto da XV\n");

  }
}